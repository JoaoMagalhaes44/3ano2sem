[![Open in Visual Studio Code](https://classroom.github.com/assets/open-in-vscode-718a45dd9cf7e7f842a935f5ebbe5719a5e09af4491e668f4dbf3b35d5cca122.svg)](https://classroom.github.com/online_ide?assignment_repo_id=14147265&assignment_repo_type=AssignmentRepo)
# bloggers-alunos-1
Implementação base para a Ficha Prática #04. Utilize-a como ponto de partida para resolver a ficha.
